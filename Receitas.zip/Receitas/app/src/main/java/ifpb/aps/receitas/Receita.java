package ifpb.aps.receitas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

    public class Receita {
    private String nome;
    private String ingredientes;
    private String instrucoes;
    private String videoReceita;

    private String comentarios;

    public Receita(String nome, String ingredientes, String instrucoes, String videoReceita, String comentarios) {
        this.nome = nome;
        this.ingredientes = ingredientes;
        this.instrucoes = instrucoes;
        this.videoReceita = videoReceita;
        this.comentarios = comentarios;
    }

    public String getNome() {
        return nome;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public String getInstrucoes() {
        return instrucoes;
    }

    public String getVideoReceita(){
        return videoReceita;
    }

    public String getComentarios(){
        return comentarios;
    }
}